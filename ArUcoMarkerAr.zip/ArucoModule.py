# Credits: https://www.youtube.com/watch?v=v5a7pKSOJd8
import cv2
import cv2.aruco as aruco
import numpy as np
import os
import pyautogui

os.chdir(os.path.dirname(__file__))

def loadAugImages(path):
    myList = os.listdir(path)
    noOfMarkers = len(myList)
    print('Total Number of Markers Detected:', noOfMarkers)
    augDics = {}
    for imgPath in myList:
        key = int(os.path.splitext(imgPath)[0])
        imgAug = cv2.imread(f'{path}/{imgPath}')
        augDics[key] = imgAug
    return augDics

def findAurcoMarkers(img, markerSize=6, totalMarkers=250, draw=True):
    imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    key = getattr(aruco, f'DICT_{markerSize}X{markerSize}_{totalMarkers}')
    arucoDict = aruco.Dictionary_get(key)
    arucoParam = aruco.DetectorParameters_create()
    bboxs, ids, rejected = aruco.detectMarkers(imgGray, arucoDict, parameters=arucoParam)
    # print(ids)
    if draw:
        aruco.drawDetectedMarkers(img, bboxs)
    return [bboxs, ids]


def augmentAurco(bbox, id, img, imgAug, drawId=True):
    tl = bbox[0][0][0], bbox[0][0][1]
    tr = bbox[0][1][0], bbox[0][1][1]
    br = bbox[0][2][0], bbox[0][2][1]
    bl = bbox[0][3][0], bbox[0][3][1]

    h, w, c = imgAug.shape # 500x500

    pts1 = np.array([tl, tr, br, bl])
    pts2 = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
    matrix, _ = cv2.findHomography(pts2, pts1)
    imgOut = cv2.warpPerspective(imgAug, matrix, (img.shape[1], img.shape[0]))
    cv2.fillConvexPoly(img, pts1.astype(int), (0, 0, 0))
    imgOut = img + imgOut
    if drawId:
        cv2.putText(imgOut, str(id), tl, cv2.FONT_HERSHEY_PLAIN, 2, (255, 0, 255), 2)

    return imgOut

def convertScreenImg(img):
    img = np.array(img) 
    img = img[:, :, ::-1].copy()
    img = cv2.resize(img, (640, 480))
    return img

def main():
    # cap = cv2.VideoCapture(0)
    audDics = loadAugImages("Markers")

    while True:
        # success, img = cap.read()
        img = pyautogui.screenshot()
        img = convertScreenImg(img)
        aurcoFound = findAurcoMarkers(img)

        # Loop through all the markers and augment each one
        if len(aurcoFound[0]) != 0:
            for bbox, id in zip(aurcoFound[0], aurcoFound[1]):
                if int(id) in audDics:
                    img = augmentAurco(bbox, id, img, audDics[int(id)])

        cv2.imshow('Image', img)
        key = cv2.waitKey(20)
        if key == 27:
            break

    # cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()