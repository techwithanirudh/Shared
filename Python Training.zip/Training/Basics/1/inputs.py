a = input('Name: ')
print('Age: ', end='')
b = input()
print(a, b)