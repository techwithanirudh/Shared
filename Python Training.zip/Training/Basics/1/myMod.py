def test(x):
    print('Hey', x)