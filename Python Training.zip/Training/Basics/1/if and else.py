a = 10
b = 11

conds = [a > 1, a > b, a - b > 1]
if all(conds):
    print('Yes')
else:
    print('No')