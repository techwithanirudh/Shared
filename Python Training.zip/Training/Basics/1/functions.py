def func(in1, in2):
    print('Henry Says', 'Hello', in1, 'Bye', in2)

def ret_func(a, b):
    return a + b

func('Jhon', 'Tim')
print(ret_func(10, 10))