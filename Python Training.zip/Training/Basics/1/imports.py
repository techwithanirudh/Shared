import myMod

myMod.test('Anirudh')