_int = 1
_string = 'Hi'
_bool = True
_float = 0.5
_list = ['a', 'dog', 'came']

print(_int, _string, _bool, _float, _list, _list[0])
# print(_int, _string, _bool, _float, end='')