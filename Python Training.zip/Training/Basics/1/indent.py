# You Should Give a tab or indent to make the file readable and when 
# python reads the file it checks for the indent 
# means tabs if there is no indent it will give error

def do_something():
    print('abc')

do_something()