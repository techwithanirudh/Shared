def do_something():
    print('abc')

do_something()