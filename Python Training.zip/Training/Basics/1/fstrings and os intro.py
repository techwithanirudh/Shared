import os

print('\n\n')
print(os.path.dirname(__file__))
os.chdir(os.path.dirname(__file__))
print(os.listdir(os.path.dirname(__file__)))

name = 'Anirudh'
print(f'Hi {name}')
print('Hi {}'.format(name))