for i in range(0, 10):
    print(i)

abcL = ['a', 'b', 'c']

for letter in abcL:
    print(letter)

while abcL[1] == 'a':
    print('a')

while True:
    print('Hi!')