times_start = 1
times_end = 10
table = input('Tables: ')

for times in range(times_start, times_end + 1):
    print(f'{table} x {times} = {table * times}')