import os, shutil, uuid

!pip install virtualenv
!virtualenv /content/FlaskBlog
!virtualenv -p /usr/bin/python3 FlaskBlog
!cp /content/code_snippets/Python/Flask_Blog/13-Deployment-Linode -r /content/FlaskBlog
os.rename('/content/FlaskBlog/13-Deployment-Linode', '/content/FlaskBlog/Main')
shutil.rmtree('/content/code_snippets')
os.chdir('/content/FlaskBlog/Main')