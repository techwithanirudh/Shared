This contains the code for **Fully Convolutional Image Classification on Arbitrary Sized Image**. For more information - visit [**Fully Convolutional Image Classification on Arbitrary Sized Image**](https://www.learnopencv.com/fully-convolutional-image-classification-on-arbitrary-sized-image/)



# AI Courses by OpenCV

Want to become an expert in AI? [AI Courses by OpenCV](https://opencv.org/courses/) is a great place to start. 

<a href="https://opencv.org/courses/">
<p align="center"> 
<img src="https://www.learnopencv.com/wp-content/uploads/2020/04/AI-Courses-By-OpenCV-Github.png">
</p>
</a>
