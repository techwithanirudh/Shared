import socket
import requests
from plyer import notification
import time
import os
import playsound

path = os.path.dirname(__file__)

while True:
    IPaddress = socket.gethostbyname(socket.gethostname())
    rtr = False

    if IPaddress == "127.0.0.1":
        print("Not connected to the router")
        notification.notify(title='Internet', message='Not connected to the router', timeout=15, app_icon=path + '/Photos/internetlogo.ico')
    else:
        print("Connected to the router")
        notification.notify(title='Internet', message='Connected to the router', timeout=15, app_icon=path + '/Photos/internetlogo.ico')
        rtr = True

    time.sleep(30)

    if rtr:
        print(rtr)
        print('Checking Internet')
        try:
            requests.get('https://google.com')
            print("Succescfully conneceted to the internet")
            notification.notify(title='Internet', message='Succescfully conneceted to the internet', timeout=15, app_icon=path + '/Photos/internetlogo.ico')
            break
        except:
            print("No internet")
            notification.notify(title='Internet', message='No internet', timeout=15, app_icon=path + '/Photos/internetlogo.ico')

    time.sleep(30)

playsound.playsound(path + '/internet.wav')