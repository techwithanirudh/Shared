var contextMenus = {};

contextMenus.createCounterString = 
  chrome.contextMenus.create(
    {'title': 'VirusTotal Search', 'contexts': ['all']}, 
    function() {
      if (chrome.runtime.lastError){
        console.error(chrome.runtime.lastError.message);
      }
    }
  );

chrome.contextMenus.onClicked.addListener(onClicked)
chrome.browserAction.onClicked.addListener(getText)

function onClicked(info, tabs) {
  if (info.menuItemId === contextMenus.createCounterString){
    getText();
  }
};

function vtSearch(searchQ) {
  console.log(searchQ);
  searchQ = encodeURIComponent(searchQ);
  searchQ = searchQ.replaceAll('%2F', '%252F');
  searchQLst = searchQ.split('');

  if (searchQLst[5] != 's') {
    searchQ = searchQ.replace('http%3A', 'http%253A');
  } else {
    searchQ = searchQ.replace('https%3A', 'https%253A');
  }

  var VTurl = 'https://www.virustotal.com/gui/search/' + searchQ; 
  window.open(VTurl);
};

function getText() {
  chrome.tabs.executeScript({
    code: 'window.getSelection().toString();'
  }, function(selection) {
    vtSearch(selection[0]);
  });
}