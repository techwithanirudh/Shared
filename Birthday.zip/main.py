from flask import *
from flask_ngrok import run_with_ngrok

app = Flask(__name__, root_path='/content/Birthday')
run_with_ngrok(app)

@app.route('/')
def ip_get():
  global jsonIp
  if request.environ.get('HTTP_X_FORWARDED_FOR') is None:
    jsonIp = {'ip': request.environ['REMOTE_ADDR']}
  else:
    jsonIp = {'ip': request.environ['HTTP_X_FORWARDED_FOR']}

  print(jsonIp)
  return redirect('/jsCheck')

@app.route('/jsCheck')
def jsCheck():
  return render_template('jsCheck.html')

@app.route('/main')
def main():
  return render_template('index.html')

app.run()