import requests
import random
import time
import os
import json

try:
    from anjanaya import FolderProtectProgramInsideRoom
    FolderProtectProgramInsideRoom.exec()
except:
    print('Init')

os.chdir(os.path.dirname(__file__))

API = 'https://www.1secmail.com/api/v1/'
domainList = ['1secmail.com', '1secmail.net', '1secmail.org']
domain = random.choice(domainList)
sentDataP = None

def extract():
    with open('mailinfo.txt', 'r') as f:
        data = json.loads(f.read())
    # jhoon@1secmail.org
    return [data['login'], data['domain']]

mail = extract()[0] + '@' + extract()[1]

def checkMails():
    global sentDataP
    reqLink = f'{API}?action=getMessages&login={extract()[0]}&domain={extract()[1]}'
    req = requests.get(reqLink).json()
    length = len(req)
    if length == 0:
        return None

    idList = []
    for i in req:
        for k,v in i.items():
            if k == 'id':
                mailId = v
                idList.append(mailId)

    current_directory = os.getcwd()
    final_directory = os.path.join(current_directory, r'All Mails')
    if not os.path.exists(final_directory):
        os.makedirs(final_directory)

    for i in idList:
        msgRead = f'{API}?action=readMessage&login={extract()[0]}&domain={extract()[1]}&id={i}'
        # print(msgRead)
        req = requests.get(msgRead).json()
        # print('Using API.json.req: ', req)
        for k,v in req.items():
            if k == 'from':
                sender = v
            if k == 'subject':
                subject = v
            if k == 'date':
                date = v
            if k == 'textBody':
                content = v

    print(sender, subject, date, content)
    mail_file_path = os.path.join(final_directory, f'{i}.txt')
    sentData = "Sender: " + sender + '\n' + "To: " + mail + '\n' + "Subject: " + subject + '\n' + "Date: " + date + '\n' + "Content: " + content + '\n'
    if sentData != sentDataP or sentData == None:
        with open(mail_file_path,'w') as file:
            file.write(sentData)
            file.close()
        sentDataP = sentData
        # print(sentDataP, sentData)
        return sentData
    else:
        return None

print('Mailbox is refreshed automatically every 5 seconds.')
while True:
    msg = checkMails()
    if msg != None:
        print('New Mail\n', msg, '\n\n\n')
    time.sleep(5)