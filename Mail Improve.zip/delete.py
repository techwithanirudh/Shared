import requests
import random
import json
import os

os.chdir(os.path.dirname(__file__))

API = 'https://www.1secmail.com/api/v1/'
domainList = ['1secmail.com', '1secmail.net', '1secmail.org']
domain = random.choice(domainList)

def extract():
    with open('mailinfo.txt', 'r') as f:
        data = json.loads(f.read())

    return [data['login'], data['domain']]

mail = extract()[0] + '@' + extract()[1]

def deleteMail():
    url = 'https://www.1secmail.com/mailbox'
    data = {
        'action': 'deleteMailbox',
        'login': f'{extract()[0]}',
        'domain': f'{extract()[1]}'
    }
    print("Disposing your email address - " + mail + '\n')
    req = requests.post(url, data=data)

deleteMail()