import pyperclip
import requests
import random
import re
import os
import json

os.chdir(os.path.dirname(__file__))

API = 'https://www.1secmail.com/api/v1/'
domainList = ['1secmail.com', '1secmail.net', '1secmail.org']
domain = random.choice(domainList)

def extract():
    getUserName = re.search(r'login=(.*)&',newMail).group(1)
    getDomain = re.search(r'domain=(.*)', newMail).group(1)
    return [getUserName, getDomain]

def writeMailInfo():
    with open('mailinfo.txt', 'a') as f:
        data = {
                'login': f'{extract()[0]}',
                'domain': f'{extract()[1]}'
            }
        f.write(json.dumps(data))

def createMail(email):
    global mail, reqMail, newMail
    newMail = f"{API}?login={email}&domain={domain}"
    reqMail = requests.get(newMail)
    mail = f"{extract()[0]}@{extract()[1]}"
    pyperclip.copy(mail)
    print(mail, ' Copied to clipboard')
    writeMailInfo()

email = input("\nEnter the name that you wish to use as your email name: ")
createMail(email)