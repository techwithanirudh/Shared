
const hamburger = document.querySelector(".hamburger");
const navLinks = document.querySelector(".nav-links");
const links = document.querySelectorAll(".nav-links li");

$(document).ready(function() {
  $(".container").click(function() {
    $(".stick").toggleClass(function () {
      navLinks.classList.toggle("open");
      links.forEach(link => {
        link.classList.toggle("fade");
      });
      return $(this).is('.open, .close') ? 'open close' : 'open';
    });
  });
});