# 1 x 22
# TODO: Fix everything

import random
import tkinter
from tkinter import messagebox
import os
from spellchecker import SpellChecker
import threading

os.chdir(os.path.dirname(__file__))

app = tkinter.Tk()
app.geometry('1500x33')
app.title('Magic Ball') 
app.iconbitmap('Images/Magic Ball.png')
spell = SpellChecker()
done = False
# black = (0, 0, 0)
# white = (255, 255, 255)
answers = ['It is Certain', 
'It is decidely so', 
'Without a doubt', 
'Yes - definitely', 
'You may rely on it', 
'As i see it, yes', 
'Most likely', 
'Outlook good', 
'Yes', 
'Signs point to yes', 
'Reply hazy, try again', 
'Ask again later', 
'Better not tell you now', 
'Cannot predict now', 
'Concentrate and ask again', 
'Don\'t count on it', 
'My reply is no', 
'My sources say no', 
'Outlook not so good', 
'Very doubtful']
correctText = True
_freeze = False
END = 'end-1c'

# def text_objects(text, font):
#     textSurface = font.render(text, True, white)
#     return textSurface, textSurface.get_rect()

# def message_display(text, x, y):
#     font = pygame.font.Font('freesansbold.ttf', 32)
#     TextSurf, TextRect = text_objects(text, font)
#     TextRect.center = ((x),(y))
#     screen.blit(TextSurf, TextRect)
#     pygame.display.update()

textBox = tkinter.Text(app, height=2, width=35, bg='light yellow', font=('arial', 16, 'bold')) 
textBox.pack() 

def ball(text):
    text = text.replace('\n', '')

def clear():
    textBox.delete('1.0', END)

def trim():
    text = textBox.get('1.0', END)
    textBox.delete('1.0', END)
    textBox.insert('1.0', text)

def handler():
    global _freeze
    while True:
        text = textBox.get('1.0', END) 

        if len(text) > 9:
            _freeze = True
        
        if len(text) < 9:
            _freeze = False

        if '\n' in text:
            clear()
            ball(text)

_handler = threading.Thread(target=handler)
_handler.start()

if _freeze:
    while True:
        print('freeze')

    # if event.type == pygame.KEYDOWN:
    #     if active:
    #         if event.key == pygame.K_RETURN:
    #             orginalText = text

    #             for word in text.split(' '):
    #                 misspelled = spell.unknown([word])

    #                 for misspelledWord in misspelled:
    #                     correctWord = spell.correction(word)

    #                 for misspelledWord in misspelled:
    #                     text = text.replace(misspelledWord, correctWord)
                            
    #                 index = 0
    #                 textL = []

    #                 for index in range(len(text.split(' '))):
    #                     textL.append(text.split(' ')[index])
    #                     index += 1

    #                 allow = True

    #                 for word in textL:
    #                     if text == '':
    #                         allow = False

    #                     if spell.unknown([word]) != set():
    #                         allow = False

    #             if allow:
    #                 if correctText:
    #                     print('You Typed:', text)
    #                 else:
    #                     print('You Typed:', orginalText)

    #                 n = random.randint(1, 20)
    #                 print(f'Answer: {answers[n - 1]}')
    #                 image = pygame.image.load(f'Images/{n}.png') 
    #                 screen = pygame.display.set_mode((610, 617)) 
    #                 screen.fill(white) 
    #                 screen.blit(image, (0, 0)) 
    #                 pygame.display.update()
    #                 pygame.time.wait(5000)
    #                 text = ''
    #                 color = color_inactive
    #                 active = False
    #                 screen = pygame.display.set_mode((1500, 33))
    #         elif event.key == pygame.K_BACKSPACE:
    #             text = text[:-1]
    #         else:
    #             text += event.unicode

    # screen.fill((30, 30, 30))
    # txt_surface = font.render(text, True, color)
    # message_display('Ask the magic ball a question', 240, 15)

    # if len(text) > 50:
    #     text = text[:-1]

    # width = max(200, txt_surface.get_width() + 10)
    # input_box.w = width
    # screen.blit(txt_surface, (input_box.x + 5, input_box.y + 5))
    # pygame.draw.rect(screen, color, input_box, 2)
    # pygame.display.flip()
    # clock.tick(30)

app.mainloop()