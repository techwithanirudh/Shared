# TODO: Fix button click radio button

import random
import pygame
import os
from spellchecker import SpellChecker

os.chdir(os.path.dirname(__file__))
pygame.init()

screen = pygame.display.set_mode((1300, 33))
pygame.display.set_caption('Magic Ball') 
icon = pygame.image.load('Images/Magic Ball.png')
pygame.display.set_icon(icon)
font = pygame.font.Font(None, 32)
clock = pygame.time.Clock()
input_box = pygame.Rect(490, 0, 0, 32)
color_inactive = pygame.Color('lightskyblue3')
color_active = pygame.Color('dodgerblue2')
spell = SpellChecker()
color = color_inactive
active = False
text = ''
done = False
black = (0, 0, 0)
white = (255, 255, 255)
answers = ['It is Certain', 
'It is decidely so', 
'Without a doubt', 
'Yes - definitely', 
'You may rely on it', 
'As i see it, yes', 
'Most likely', 
'Outlook good', 
'Yes', 
'Signs point to yes', 
'Reply hazy, try again', 
'Ask again later', 
'Better not tell you now', 
'Cannot predict now', 
'Concentrate and ask again', 
'Don\'t count on it', 
'My reply is no', 
'My sources say no', 
'Outlook not so good', 
'Very doubtful']
correctText = True

# class Checkbox:
#     def __init__(self, surface, x, y, color=white, caption='', outline_color=black,
#                  check_color=black, font_size=22, font_color=white, text_offset=(55, 1)):
#         self.surface = surface
#         self.x = x
#         self.y = y
#         self.color = color
#         self.caption = caption
#         self.oc = outline_color
#         self.cc = check_color
#         self.fs = font_size
#         self.fc = font_color
#         self.to = text_offset
#         self.checkbox_obj = pygame.Rect(self.x, self.y, 12, 12)
#         self.checkbox_outline = self.checkbox_obj.copy()
#         self.checked = False
#         self.active = False
#         self.click = False

#     def _draw_button_text(self):
#         self.font = pygame.font.Font(None, self.fs)
#         self.font_surf = self.font.render(self.caption, True, self.fc)
#         w, h = self.font.size(self.caption)
#         self.font_pos = (self.x + 12 / 2 - w / 2 + self.to[0], self.y + 12 / 2 - h / 2 + self.to[1])
#         self.surface.blit(self.font_surf, self.font_pos)

#     def render_checkbox(self):
#         if self.checked:
#             pygame.draw.rect(self.surface, self.color, self.checkbox_obj)
#             pygame.draw.rect(self.surface, self.oc, self.checkbox_outline, 1)
#             pygame.draw.circle(self.surface, self.cc, (self.x + 6, self.y + 6), 7)
#         elif not self.checked:
#             pygame.draw.rect(self.surface, self.color, self.checkbox_obj)
#             pygame.draw.rect(self.surface, self.oc, self.checkbox_outline, 1)

#         self._draw_button_text()

#     def _update(self, event_object):
#         x, y = event_object.pos
#         px, py, w, h = self.checkbox_obj
#         if px < x < px + w and px < x < px + w:
#             self.active = True
#         else:
#             self.active = False

#         print(str(self.caption) + ' toggle ' + str(self.checked))

#     def _mouse_up(self):
#         if self.active and not self.checked and self.click:
#             self.checked = True
#         elif self.checked:
#             self.checked = False

#         if self.click is True and self.active is False:
#             if self.checked:
#                 self.checked = True

#             self.active = False

#     def update_checkbox(self, event_object):
#         if event_object.type == pygame.MOUSEBUTTONDOWN:
#             self.click = True
#         if event_object.type == pygame.MOUSEBUTTONUP:
#             self._mouse_up()
#         if event_object.type == pygame.MOUSEMOTION:
#             self._update(event_object)

#     def is_checked(self):
#         if self.checked is True:
#             return True
#         else:
#             return False

def text_objects(text, font):
    textSurface = font.render(text, True, white)
    return textSurface, textSurface.get_rect()

def message_display(text, x, y):
    font = pygame.font.Font('freesansbold.ttf', 32)
    TextSurf, TextRect = text_objects(text, font)
    TextRect.center = ((x),(y))
    screen.blit(TextSurf, TextRect)
    pygame.display.update()

# chkbox = Checkbox(screen, 1320, 10, caption='Correct Text')

while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

        # chkbox.update_checkbox(event)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if input_box.collidepoint(event.pos):
                active = not active
            else:
                active = False

            color = color_active if active else color_inactive

        if event.type == pygame.KEYDOWN:
            if active:
                if event.key == pygame.K_RETURN:
                    orginalText = text

                    for word in text.split(' '):
                        misspelled = spell.unknown([word])

                        for misspelledWord in misspelled:
                            correctWord = spell.correction(word)

                        for misspelledWord in misspelled:
                            text = text.replace(misspelledWord, correctWord)
                            
                        index = 0
                        textL = []

                        for index in range(len(text.split(' '))):
                            textL.append(text.split(' ')[index])
                            index += 1

                        allow = True

                        for word in textL:
                            if text == '':
                                allow = False

                            if spell.unknown([word]) != set():
                                allow = False

                    if allow:
                        if correctText:
                            print('You Typed:', text)
                        else:
                            print('You Typed:', orginalText)

                        n = random.randint(1, 20)
                        print(f'Answer: {answers[n - 1]}')
                        image = pygame.image.load(f'Images/{n}.png') 
                        screen = pygame.display.set_mode((610, 617)) 
                        screen.fill(white) 
                        screen.blit(image, (0, 0)) 
                        pygame.display.update()
                        pygame.time.wait(5000)
                        text = ''
                        color = color_inactive
                        active = False
                        screen = pygame.display.set_mode((1500, 33))
                elif event.key == pygame.K_BACKSPACE:
                    text = text[:-1]
                else:
                    text += event.unicode

    screen.fill((30, 30, 30))
    txt_surface = font.render(text, True, color)
    message_display('Ask the magic ball a question', 240, 15)
    # chkbox.render_checkbox()
    # correctText = chkbox.is_checked()

    if len(text) > 50:
        text = text[:-1]

    width = max(200, txt_surface.get_width() + 10)
    input_box.w = width
    screen.blit(txt_surface, (input_box.x + 5, input_box.y + 5))
    pygame.draw.rect(screen, color, input_box, 2)
    pygame.display.flip()
    clock.tick(30)

# import pygame

# def main():
#     WIDTH = 800
#     HEIGHT = 600
#     display = pygame.display.set_mode((WIDTH, HEIGHT))

#     chkbox = Checkbox(display, 400, 400)

#     running = True
#     while running:
#         for event in pygame.event.get():
#             if event.type == pygame.QUIT:
#                 running = False
#                 pygame.quit()
#                 quit()
#             chkbox.update_checkbox(event)

#         display.fill((200, 200, 200))
#         chkbox.render_checkbox()
#         print(chkbox.is_checked())
#         pygame.display.flip()

# main()