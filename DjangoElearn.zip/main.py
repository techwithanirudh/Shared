import os

ftime = False # first time running this file

os.chdir('/home/runner/DjangoElearn')
os.system('chmod u+x ./su')

if ftime:
	os.system('chmod u+x ./firsttime')
	os.system('chmod u+x ./startup')
	os.system('./firsttime')

if not ftime:
	os.system('chmod u+x ./startup')
	os.system('./startup')

# README.txt

# Error: https://stackoverflow.com/questions/48549068/django-db-utils-notsupportederror-in-sqlite-why-not-supported-in-sqlite
# setting: Allowed host: https://djangoelearn.techwithanirudh.repl.co/
# Error: Change migrate courses.0007_auto_20200315_1023. In first line in migrate class create variable atomic and set it to false
# If you want create superuser: run ./su in home directory
# Error: Django no file named default.png. Copy default.png to the mesoOn folder