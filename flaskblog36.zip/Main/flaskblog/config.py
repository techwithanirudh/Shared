
import os, uuid

key = str(uuid.uuid4())

class Config:
    SECRET_KEY = key
    SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = '***'
    MAIL_PASSWORD = '***'
