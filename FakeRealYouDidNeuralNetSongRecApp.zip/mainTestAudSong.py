from liveaud import main as liveaud
from keras_load_model_minified import main as keras

liveFeed = liveaud.start_rec(10)
model = keras.load_model('D:\Anirudh\pythonprojects\sampleproject1\models\model.h5')
print(model.predict(liveFeed))