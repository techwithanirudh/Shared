import time
import tkinter
from myModules import browser
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from tkinter import messagebox
import os
import threading

def load_model(model_F):
    global model_Fc
    model_Fc = model_F
    os.system('cls')
    print('Done! successfully loaded ' + model_F)
    return _load_model()

def _predict():
    global browser
    tkinter.Tk().withdraw()
    options = Options()
    options.add_argument('--log-level=3')
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    options.add_argument('use-fake-ui-for-media-stream')
    options.add_argument('--headless')
    browser = browser.Chrome(options=options)
    browser.get("https://www.aha-music.com/")
    time.sleep(3)

    os.system('cls')
    print('Done! successfully loaded ' + model_Fc)
    messagebox.showinfo('Recording', 'Click This When You Would Like To Recognize The Song')
    print('Predicting this may take a moment!')
    browser.find_element(By.XPATH, "//div[@id='__layout']/div/div/div[2]/div/button").click()
    time.sleep(12)

    data = browser.find_element(By.XPATH, "/html/body/div/div/div/div/div[2]/div[1]/div/div[1]").text
    browser.close()

    return data

class _load_model():
    def predict(self, liveFeed):
        return _predict()