def start_rec(sec):
    return ''