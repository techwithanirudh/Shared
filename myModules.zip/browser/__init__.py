from selenium import webdriver
import os

def Chrome(options=None):
    browser = webdriver.Chrome(executable_path='{}/chromedriver.exe'.format(os.path.dirname(__file__)), options=options) 
    browser.maximize_window()
    return browser

def Firefox(options=None):
    browser = webdriver.Firefox(executable_path='{}/geckodriver.exe'.format(os.path.dirname(__file__)), options=options)
    browser.maximize_window()
    return browser

def Edge(options=None):
    browser = webdriver.Edge(executable_path='{}/msedgedriver.exe'.format(os.path.dirname(__file__)))
    browser.maximize_window()
    return browser

# Testing stuff
if __name__ == '__main__':
    import time

    browser = Chrome()
    browser1 = Firefox()
    browser2 = Edge()

    browser2.get('https://www.google.com/')
    browser1.get('https://www.google.com/')
    browser.get('https://www.google.com/')

    time.sleep(5)

    browser.close()
    browser1.close()
    browser2.close()