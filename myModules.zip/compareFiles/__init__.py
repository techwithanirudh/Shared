def compareFiles(inputFile, outputFile):
    Ifile = open(inputFile, 'rb')
    Ofile = open(outputFile, 'rb')

    if Ifile.read() == Ofile.read():
        return True

    return False