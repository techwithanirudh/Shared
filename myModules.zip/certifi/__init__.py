import cv2
import os
from fpdf import FPDF

def certifi(name, date, secratery, title, font_color=(93, 0, 0), font=cv2.FONT_HERSHEY_SCRIPT_COMPLEX):
    template_path = '{}/template.png'.format(os.path.dirname(__file__))
    certi = cv2.imread(template_path) 
    try:
        title_new = title.split('\ln')[1]
        title = title.split('\ln')[0]
    except IndexError:
        title_new = ''
    name_size = cv2.getTextSize(name, font, 3, 3)[0]
    date_size = cv2.getTextSize(date, font, 1, 0)[0]
    secratery_size = cv2.getTextSize(secratery, font, 2, 1)[0]
    title_size = cv2.getTextSize(title, font, 2, 1)[0]
    title_sizenew = cv2.getTextSize(title_new, font, 2, 1)[0]
    title_x = int((certi.shape[1] - title_size[0]) / 2 + len(title) * 5)
    title_y = int((certi.shape[0] + title_size[1]) / 2 - 80)
    titlenew_x = int((certi.shape[1] - title_sizenew[0]) / 2 + len(title_new) * 5)
    titlenew_y = int((certi.shape[0] + title_sizenew[1]) / 2 - 30)
    name_x = int((certi.shape[1] - name_size[0]) / 2 + 60)
    name_y = int((certi.shape[0] + name_size[1]) / 2 - -20)
    date_x = int((certi.shape[1] - date_size[0]) / 2 + -140)
    date_y = int((certi.shape[0] + date_size[1]) / 2 - -150)
    secratery_x = int((certi.shape[1] - secratery_size[0]) / 2 + 350)
    secratery_y = int((certi.shape[0] + secratery_size[1]) / 2 - -140)
    cv2.putText(certi, name, (name_x, name_y), font, 2, font_color, 3) 
    cv2.putText(certi, date, (date_x, date_y), font, 0.5, font_color, 0) 
    cv2.putText(certi, secratery, (secratery_x, secratery_y), font, 0.6, font_color, 1) 
    cv2.putText(certi, title, (title_x, title_y), font, 1.3, (255, 64, 0), 1) 
    cv2.putText(certi, title_new, (titlenew_x, titlenew_y), font, 1.3, (255, 64, 0), 1)
    return certi

def sImg(path, certi):
    cv2.imwrite(path, certi)

def sPDF(path, certi):
    pdf = FPDF()
    img = '{}/tmp.png'.format(os.path.dirname(__file__))
    cv2.imwrite(img, certi)
    pdf.add_page()
    pdf.image(img, 10, 100, w=190, h=130)
    pdf.output(path, 'F') 

if __name__ == '__main__':
    print('1. For Save As Image\n2. For Save As Pdf')
    try:
        inp = int(input()) 
    except ValueError:
        raise SystemExit()
  
    if inp == 1:
        certi = certifi('Anirudh', '28/10/2020', 'Anirudh Sriram' + ' ' * 4, 'For Making This Program')
        cv2.imshow('Certificate', certi)
        path = '{}/certificate.pdf'.format(os.path.dirname(__file__))
        sImg(path, certi)
        cv2.waitKey(0)
    if inp == 2:
        certi = certifi('Anirudh', '28/10/2020', 'Anirudh Sriram' , 'For Making This Program')
        cv2.imshow('Certificate', certi)
        path = '{}/certificate.pdf'.format(os.path.dirname(__file__))
        sPDF(path, certi)
        cv2.waitKey(0)