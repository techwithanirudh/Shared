import os
import time

class Watcher(object):
    '''
    Watches file and calls a custom function you define when the file changes
    'ERRORS'
    '''
    def __init__(self, filename, func_name, refresh_delay_secs=2):
        self.refresh_delay_secs = refresh_delay_secs
        self._cached_stamp = 0
        self.filename = filename
        self.func_name = func_name
        self.run = True

    def look(self):
        stamp = os.stat(self.filename).st_mtime
        if stamp != self._cached_stamp:
            self._cached_stamp = stamp
            exec(f'{self.func_name}()')

    def start(self):
        while self.run: 
            try:
                time.sleep(self.refresh_delay_secs) 
                self.look() 
            except: 
                time.sleep(0.01)

    def stop(self):
        self.run = False

'''
How To Define Functions
'''
count = 0
def func_name():
    global count
    count += 1
    if count > 1:
        ...