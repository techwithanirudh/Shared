import cv2
import numpy as np
import requests

def read(ip, flipL=False, flipV=False):
    '''
    Give the current Ip of IpWebcam and it will return the current frame
    '''
    url = f'https://{ip}:8080/shot.jpg'

    while True:
        raw_data = requests.get(url, verify=False)
        image_array = np.array(bytearray(raw_data.content), dtype=np.uint8)
        frame = cv2.imdecode(image_array, -1)
        frame = cv2.resize(frame, (640, 480))

        if flipL:
            frame = cv2.flip(frame, 1)

        if flipV:
            frame = cv2.flip(frame, 0)

        return frame

if __name__ == '__main__':
    ip = input('IpCamera Ip: ')

    while True:
        cv2.imshow('LiveFeed', read(ip))

        key = cv2.waitKey(20)
        if key == 27: # esc
            break