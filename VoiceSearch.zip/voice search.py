from tkinter import *
from tkinter import ttk
import speech_recognition as sr
from pygame import mixer
import sys
import os
from myModules import browser
from textblob import TextBlob  

os.chdir(os.path.dirname(__file__))
text = input('Enter any word from your language: ')
lang = TextBlob(text).detect_language()
browser = browser.Chrome()	

print(f'\nOpening {browser.name.title()} browser')

root = Tk()

root.title('Universal Search Bar')
root.iconbitmap('mic.ico')

style = ttk.Style()
style.theme_use('winnative')

photo = PhotoImage(file='microphone.png').subsample(15,15)

label1 = ttk.Label(root, text='Query:')
label1.grid(row=0, column=0)
entry1 = ttk.Entry(root, width=40)
entry1.grid(row=0, column=1, columnspan=4)

btn2 = StringVar()
recognizer = sr.Recognizer()
microphone = sr.Microphone()
print("A moment of silence, please...")
with microphone as source: recognizer.adjust_for_ambient_noise(source)
print("Set minimum energy threshold to {}".format(recognizer.energy_threshold))

def callback():
    if btn2.get() == 'google' and entry1.get() != '':
        browser.get('http://google.com/search?q='+entry1.get())
        
    elif btn2.get() == 'duck duck go' and entry1.get() != '':
        browser.get('http://duckduckgo.com/?q='+entry1.get())

    elif btn2.get() == 'amazon' and entry1.get() != '':
        browser.get('https://amazon.com/s/?url=search-alias%3Dstripbooks&field-keywords='+entry1.get())

    elif btn2.get() == 'youtube' and entry1.get() != '':
        browser.get('https://www.youtube.com/results?search_query='+entry1.get())

    else:
        pass

def get(event):
    if btn2.get() == 'google' and entry1.get() != '':
        browser.get('http://google.com/search?q='+entry1.get())
        
    elif btn2.get() == 'duck duck go' and entry1.get() != '':
        browser.get('http://duckduckgo.com/?q='+entry1.get())

    elif btn2.get() == 'amazon' and entry1.get() != '':
        browser.get('https://amazon.com/s/?url=search-alias%3Dstripbooks&field-keywords='+entry1.get())

    elif btn2.get() == 'youtube' and entry1.get() != '':
        browser.get('https://www.youtube.com/results?search_query='+entry1.get())

    else:
        pass

def speech_recognition():
    Repeat = True
    while Repeat:
        with microphone as source: audio = recognizer.listen(source)
        try:
            print(lang)
            value = recognizer.recognize_google(audio, language=lang)
            try:
                value = TextBlob(value).translate(from_lang=lang, to='en')
            except:
                value = value
            Repeat = False
        except sr.UnknownValueError:
            print("Oops! Didn't catch that")
            Repeat = True
        except sr.RequestError as error:
            print("Uh oh! Couldn't request results from Google Speech Recognition service; {0}".format(error))
            sys.exit()
    return str(value)

def buttonClick():
    mixer.init()
    mixer.music.load('chime1.mp3')
    mixer.music.play()

    message = speech_recognition()
    mixer.music.load('chime2.mp3')
    mixer.music.play()
    entry1.focus()
    entry1.delete(0, END)
    entry1.insert(0, message)
    if btn2.get() == 'google':
        browser.get('http://google.com/search?q='+message)
    elif btn2.get() == 'duck duck go':
        browser.get('http://duckduckgo.com/?q='+message)
    elif btn2.get() == 'amazon':
        browser.get('https://amazon.com/s/?url=search-alias%3Dstripbooks&field-keywords='+message)
    elif btn2.get() == 'youtube':
        browser.get('https://www.youtube.com/results?search_query='+message)
    else:
        pass

entry1.bind('<Return>', get)

MyButton1 = ttk.Button(root, text='Search', width=10, command=callback)
MyButton1.grid(row=0, column=6)

MyButton2 = ttk.Radiobutton(root, text='Google', value='google', variable=btn2)
MyButton2.grid(row=1, column=1, sticky=W)

MyButton3 = ttk.Radiobutton(root, text='Duck Duck Go', value='duck duck go', variable=btn2)
MyButton3.grid(row=1, column=2, sticky=W)

MyButton4 = ttk.Radiobutton(root, text='Amazon', value='amazon', variable=btn2)
MyButton4.grid(row=1, column=3)

MyButton5 = ttk.Radiobutton(root, text='Youtube', value='youtube', variable=btn2)
MyButton5.grid(row=1, column=4, sticky=E)

MyButton6 = Button(root, image=photo, command=buttonClick, bd=0, activebackground='#c1bfbf', overrelief='groove', relief='sunken')
MyButton6.grid(row=0, column=5)

entry1.focus()
root.wm_attributes('-topmost', 1)
btn2.set('google')

root.mainloop()