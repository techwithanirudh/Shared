from selenium import webdriver

def Chrome():
    browser = webdriver.Chrome(executable_path ='D:\Anirudh\pythonprojects\sampleproject1\chromedriver.exe') 
    browser.maximize_window()
    return browser

def Firefox():
    browser = webdriver.Firefox(executable_path ='D:\Anirudh\pythonprojects\sampleproject1\geckodriver.exe')
    browser.maximize_window()
    return browser

# Testing stuff
if __name__ == '__main__':
    import time

    browser = Chrome()
    browser1 = Firefox()

    browser1.get('https://www.google.com/')
    browser.get('https://www.google.com/')

    time.sleep(5)

    browser.close()
    browser1.close()