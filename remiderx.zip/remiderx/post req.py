import requests

url = 'http://localhost:5000/api/reminders'
myobj = {
  'due_date': '2020-1-08',
  'interval': 'daily',
  'message': 'bye',
}
req = requests.post(url, json=myobj) 
print(req.text)

# import requests

# url = 'http://localhost:5000/api/reminders/ca5920bec9e440ce9b90daf870eccb31'
# req = requests.delete(url) 
# print(req.text)