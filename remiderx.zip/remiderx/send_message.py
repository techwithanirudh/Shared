import os
from reminder_json_helper import read_reminder_json, write_reminder_json
from dateutil.relativedelta import relativedelta
from datetime import datetime, date
from plyer import notification

os.chdir(os.path.dirname(__file__))

def find_reminders_due():
    reminders = read_reminder_json()
    reminders_due = [
        reminder for reminder in reminders
        if reminder['due_date'] == str(date.today())
    ]
    if len(reminders_due) > 0:
        send_sms_reminder(reminders_due)

def send_sms_reminder(reminders):
    import time
    for reminder in reminders:
        print(reminder)
        wait = int(reminder['interval'])
        notification.notify(title='Reminder', message=reminder['message'], timeout=wait, app_icon='calendar.ico')
        time.sleep(wait + 1)
        delete_reminder(reminder)

def delete_reminder(reminder):
    reminders = read_reminder_json()
    reminder_id = reminder['id']
    reminder = [
        reminder for reminder in reminders if reminder['id'] == reminder_id
    ]
    reminders.remove(reminder[0])
    data = {}
    data['reminders'] = reminders
    write_reminder_json(data)

if __name__ == '__main__':
    find_reminders_due()