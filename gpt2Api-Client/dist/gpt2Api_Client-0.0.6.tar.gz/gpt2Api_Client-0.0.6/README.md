# vidstream

Under construction!

Developed by Anirudh from TechWithAnirudh (c) 2021

## Examples of How To Use (Alpha Version)

Creating A Request
```python
start_paragraph = "Today was a fine day. I woke up and brushed my teeth. And Ate Breakfast. I was going to work When"
api = Api()
api.setGitUrl(input('Enter The Git URL: '))
api.ConditionalSamples(start_paragraph)
```

Very Easy To To Use GPT2 Wrapper

### Info

See The Docs On How To Use This: https://techwithanirudh.blogspot.com/2021/03/docs-for-gpt2api-client-module.html

Check out: https://www.youtube.com/channel/UCmse86kaxJ3n1dDT_bXDukg