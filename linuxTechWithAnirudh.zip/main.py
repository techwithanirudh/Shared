import json, os, subprocess

def source(file_to_source_path, include_unexported_variables=False):
    source = '%ssource %s' % ("set -a && " if include_unexported_variables else "", file_to_source_path)
    dump = '/usr/bin/python -c "import os, json; print json.dumps(dict(os.environ))"'
    pipe = subprocess.Popen(['/bin/bash', '-c', '%s && %s' % (source, dump)], stdout=subprocess.PIPE)
    return json.loads(pipe.stdout.read())

print('Setting Up...')
os.chdir('Main')
os.system('pip install virtualenv')
os.system('virtualenv Main')
source('activate')
os.system('pip install -r requirements.txt')
os.system('python3 run.py')