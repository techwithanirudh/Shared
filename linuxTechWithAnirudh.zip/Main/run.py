from flaskblog import create_app, db
from flaskblog import db
from authlib.integrations.flask_client import OAuth

app = create_app()
oauth = OAuth(app)

with app.app_context():
  db.create_all()

if __name__ == '__main__':
  app.run('0.0.0.0', port=8080)