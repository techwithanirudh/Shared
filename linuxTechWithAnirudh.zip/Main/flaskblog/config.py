import os

class Config:
    SECRET_KEY = os.urandom(24)
    SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = '***'
    MAIL_PASSWORD = '***'
    GOOGLE_CLIENT_ID = '719152412046-kn8iumtgbe0rlcvutuatsm8i36l23uk5.apps.googleusercontent.com'
    GOOGLE_CLIENT_SECRET = '-lUJJmCGFAekRZ6Frj-aRRvf'
    GITHUB_CLIENT_ID = '8e0f5dc42dc0bb0506fd'
    GITHUB_CLIENT_SECRET = '7e6017b915712df82269adebb39bfc225f403a30'
