from utils import *
import os
from sklearn.model_selection import train_test_split

os.chdir(os.path.dirname(__file__))

#### STEP 1

path = 'myData'
data = importDataInfo(path)

#### STEP 2
data = balanceData(data, display=False)

#### STEP 3
imagesPath, steerings = loadData(path,data)
print(imagesPath[0], steerings[0])

#### STEP 4
xTrain, xVal, yTrain, yVal = train_test_split(imagesPath, steerings, test_size=0.2, random_state=5)
print('Total Training Images: ', len(xTrain))
print('Total Validation Images: ', len(xVal))

#### STEP 5
