# ChatBox-UI-Like-Whatsapp

How To Create ChatBox (Message Box) Using HTML and CSS. Like Whatsapp

► [Subscribe Us:](https://www.youtube.com/codingwithelias?sub_confirmation=1)

[See Demo](https://eliasfsdev.github.io/ChatBox-UI-Like-Whatsapp/)

![img](https://github.com/eliasFsDev/ChatBox-UI-Like-Whatsapp/blob/master/2.png)

Just a simple HTML &amp; CSS Tutorial.

Chat Web App UI Design.
