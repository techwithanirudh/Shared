import requests

url = 'http://localhost:5000/api/reminders'
myobj = {
  'due_date': '2020-12-08',
  'interval': 'daily',
  'message': 'Sing',
  'phone_number': '+xxxx'
}
req = requests.post(url, json=myobj) 
print(req.text)