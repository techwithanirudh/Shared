import cv2
import dlib
import os

path = os.path.dirname(__file__)

os.chdir(path)

os.system('python download.py ' + path)

cap = cv2.VideoCapture(0)
# cv2.namedWindow('Frame')

detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor('shape_predictor_68_face_landmarks.dat')
landmarks_frame = cv2.imread('blank.png')
# w, h = cv2.getWindowImageRect('Frame')[2], cv2.getWindowImageRect('Frame')[3]
# print(w, h)

while True:
	_, frame = cap.read()
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

	faces = detector(gray)
	for face in faces:
		x1 = face.left()
		y1 = face.top()
		x2 = face.right()
		y2 = face.bottom()
		# cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 3)

		landmarks = predictor(gray, face)
		landmarks_frame = cv2.imread('blank.png')

		for n in range(0, 68):
			x = landmarks.part(n).x
			y = landmarks.part(n).y
			cv2.circle(frame, (x, y), 4, (255, 0, 0), -1)
			cv2.circle(landmarks_frame, (x, y), 4, (255, 0, 0), -1)

	cv2.imshow('Landmarks', landmarks_frame)
	cv2.imshow('Frame', frame)

	key = cv2.waitKey(20)
	if key == 27:
	    break