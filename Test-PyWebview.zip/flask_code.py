from flask import Flask
from url import set_url

url = 'http://127.0.0.1:5000/'
set_url(url)
app = Flask(__name__)

@app.route('/')
def index():
    return 'Hello'

app.run()