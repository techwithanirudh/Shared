import threading
import webview
import os
from url import get_url

os.chdir(os.path.dirname(__file__))

path = './flask_code.py'
url = False

def flaskCode(path):
    global url
    with open(path, 'r') as flask_code:
        code = flask_code.read()
        exec(code)
    flask_code.close()

threading.Thread(target=flaskCode, args=(path,)).start()
url = get_url()
webview.create_window('Hello world', url)
webview.start(gui='cef')