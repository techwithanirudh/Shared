import os

os.chdir(os.path.dirname(__file__))

open('url.url', 'a')

def set_url(url):
    with open('url.url', 'w') as url_file:
        url_file.write(url)
    url_file.close()

def get_url():
    url = ''
    with open('url.url', 'r') as url_file:
        while not url != '':
            url = url_file.read()
        url_file.close()

    return url