# Designer

# Launch Designer
# -> designer

# Convert Ui File To Python File
# -> pyuic5 -x main.ui -o main.py
