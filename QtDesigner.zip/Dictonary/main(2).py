from PyQt5 import QtCore, QtGui, QtWidgets
from PyDictionary import PyDictionary
import pyttsx3
from datetime import datetime
import os

class Ui_winMain(object):
    def __init__(self):
        self.Mrun = False
        self.Arun = False
        self.Srun = False

    def delVar(self):
        self.Mrun = False
        self.Arun = False
        self.Srun = False

    def blank(self):
        self.txtMeaning.setText(self._translate('winMain', ''))
        self.txtAntonyms.setText(self._translate('winMain', ''))
        self.txtSynonyms.setText(self._translate('winMain', ''))

    def log(self, word, Vtype, data):
        try:
            now = datetime.now()
            path = os.path.expanduser('~') + '/Documents'
            with open(f'{path}/newWords.txt', 'a') as file:
                file.write('\n' + f"{now.strftime('%A, %B %d, %Y, %I:%M %p|')}" + word + '|' + Vtype + '|' + str(data))
        except PermissionError:
            QtWidgets.QMessageBox.warning(None, 'Error', f'Please Close {path}/newWords.txt', QtWidgets.QMessageBox.Ok)

    def btnPronounce_clicked(self):
        word = self.txtWord.toPlainText().replace('\n', '')
        if len(word.split()) < 2:
            self.converter.say(word)
            self.converter.runAndWait()

    def btnGetMeaning_clicked(self):
        self.Mrun = True
        if self.Srun:
            self.blank()
            self.Srun = False

        word = self.txtWord.toPlainText().replace('\n', '')
        meaning = str(self.dictionary.meaning(word))
        if meaning != '{.}'.replace('.', '') and meaning != 'None':
            self.txtMeaning.setText(self._translate('winMain', meaning))
            self.log(word, 'Meaning', meaning)

    def btnGetAntonyms_clicked(self):
        self.Arun = True
        if self.Mrun:
            self.blank()
            self.Mrun = False
        if self.Srun:
            self.blank()
            self.Srun = False

        word = self.txtWord.toPlainText().replace('\n', '')
        antonyms = str(self.dictionary.antonym(word))

        if antonyms != '{.}'.replace('.', '') and antonyms != 'None':
            self.txtAntonyms.setText(self._translate('winMain', antonyms))
            self.log(word, 'Antonyms', antonyms)

    def btnGetSynonyms_clicked(self):
        self.Srun = True
        if self.Arun:
            self.blank()
            self.Arun = False

        word = self.txtWord.toPlainText().replace('\n', '')
        synonyms = str(self.dictionary.synonym(word))

        if synonyms != '{.}'.replace('.', '') and synonyms != 'None':
            self.txtSynonyms.setText(self._translate('winMain', synonyms))
            self.log(word, 'Synonyms', synonyms)

    def btnGetAll_clicked(self):
        self.delVar()
        self.btnGetMeaning_clicked()
        self.delVar()
        self.btnGetAntonyms_clicked()
        self.delVar()
        self.btnGetSynonyms_clicked()

    def setupUi(self, winMain):
        winMain.setObjectName('winMain')
        winMain.resize(1170, 326)
        self.dictionary = PyDictionary()
        self.converter = pyttsx3.init()
        self.converter.setProperty('rate', 70) 
        self.centralwidget = QtWidgets.QWidget(winMain)
        self.centralwidget.setObjectName('centralwidget')
        self.txtMeaning = QtWidgets.QTextBrowser(self.centralwidget)
        self.txtMeaning.setEnabled(True)
        self.txtMeaning.setGeometry(QtCore.QRect(10, 130, 371, 171))
        self.txtMeaning.setObjectName('txtMeaning')
        self.lblMeaning = QtWidgets.QLabel(self.centralwidget)
        self.lblMeaning.setGeometry(QtCore.QRect(160, 110, 41, 16))
        self.lblMeaning.setObjectName('lblMeaning')
        self.txtAntonyms = QtWidgets.QTextBrowser(self.centralwidget)
        self.txtAntonyms.setGeometry(QtCore.QRect(400, 130, 371, 171))
        self.txtAntonyms.setObjectName('txtAntonyms')
        self.lblAntonyms = QtWidgets.QLabel(self.centralwidget)
        self.lblAntonyms.setGeometry(QtCore.QRect(550, 110, 51, 16))
        self.lblAntonyms.setObjectName('lblAntonyms')
        self.txtSynonyms = QtWidgets.QTextBrowser(self.centralwidget)
        self.txtSynonyms.setGeometry(QtCore.QRect(790, 130, 371, 171))
        self.txtSynonyms.setObjectName('txtSynonyms')
        self.lblSynonyms = QtWidgets.QLabel(self.centralwidget)
        self.lblSynonyms.setGeometry(QtCore.QRect(950, 110, 51, 20))
        self.lblSynonyms.setObjectName('lblSynonyms')
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(360, 0, 458, 51))
        self.widget.setObjectName('widget')
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout(self.widget)
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_3.setObjectName('horizontalLayout_3')
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName('gridLayout')
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName('horizontalLayout_2')
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName('horizontalLayout')
        self.lblWord = QtWidgets.QLabel(self.widget)
        self.lblWord.setObjectName('lblWord')
        self.horizontalLayout.addWidget(self.lblWord)
        self.txtWord = QtWidgets.QTextEdit(self.widget)
        self.txtWord.setObjectName('txtWord')
        self.horizontalLayout.addWidget(self.txtWord)
        self.horizontalLayout_2.addLayout(self.horizontalLayout)
        self.btnPronounce = QtWidgets.QPushButton(self.widget)
        self.btnPronounce.setObjectName('btnPronounce')
        self.horizontalLayout_2.addWidget(self.btnPronounce)
        self.gridLayout.addLayout(self.horizontalLayout_2, 0, 0, 1, 3)
        self.btnGetMeaning = QtWidgets.QPushButton(self.widget)
        self.btnGetMeaning.setObjectName('btnGetMeaning')
        self.gridLayout.addWidget(self.btnGetMeaning, 1, 0, 1, 1)
        self.btnGetAntonyms = QtWidgets.QPushButton(self.widget)
        self.btnGetAntonyms.setObjectName('btnGetAntonyms')
        self.gridLayout.addWidget(self.btnGetAntonyms, 1, 1, 1, 1)
        self.btnGetSynonyms = QtWidgets.QPushButton(self.widget)
        self.btnGetSynonyms.setObjectName('btnGetSynonyms')
        self.gridLayout.addWidget(self.btnGetSynonyms, 1, 2, 1, 1)
        self.horizontalLayout_3.addLayout(self.gridLayout)
        self.btnGetAll = QtWidgets.QPushButton(self.widget)
        self.btnGetAll.setObjectName('btnGetAll')
        self.horizontalLayout_3.addWidget(self.btnGetAll)
        winMain.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(winMain)
        self.statusbar.setObjectName('statusbar')
        winMain.setStatusBar(self.statusbar)
        self.retranslateUi(winMain)
        QtCore.QMetaObject.connectSlotsByName(winMain)

    def retranslateUi(self, winMain):
        self._translate = QtCore.QCoreApplication.translate
        winMain.setWindowTitle(self._translate('winMain', 'Dictionary'))
        self.lblMeaning.setText(self._translate('winMain', 'Meaning'))
        self.lblAntonyms.setText(self._translate('winMain', 'Antonyms'))
        self.lblSynonyms.setText(self._translate('winMain', 'Synonyms'))
        self.lblWord.setText(self._translate('winMain', 'Word'))
        self.btnPronounce.setText(self._translate('winMain', 'Pronounce'))
        self.btnGetMeaning.setText(self._translate('winMain', 'Get Meaning'))
        self.btnGetAntonyms.setText(self._translate('winMain', 'Get Antonyms'))
        self.btnGetSynonyms.setText(self._translate('winMain', ' Get Synonyms'))
        self.btnGetAll.setText(self._translate('winMain', 'Get All'))
        self.btnPronounce.clicked.connect(self.btnPronounce_clicked)
        self.btnGetMeaning.clicked.connect(self.btnGetMeaning_clicked)
        self.btnGetAntonyms.clicked.connect(self.btnGetAntonyms_clicked)
        self.btnGetSynonyms.clicked.connect(self.btnGetSynonyms_clicked)
        self.btnGetAll.clicked.connect(self.btnGetAll_clicked)

if __name__ == '__main__':
    import sys
    app = QtWidgets.QApplication(sys.argv)
    winMain = QtWidgets.QMainWindow()
    ui = Ui_winMain()
    ui.setupUi(winMain)
    winMain.show()
    sys.exit(app.exec_())