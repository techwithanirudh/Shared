# Designer

# Launch Designer
# -> designer

# Convert Ui File To Python File
# -> pyuic5 -x Ui.ui -o main.py
