from os.path import dirname
from plyer import notification

book = ''
pgNum = ''
notification.notify(title='StoryReminder', message=f'Read the book {book} and the page number is {pgNum}', app_icon=f'{dirname(__file__)}/book.ico')